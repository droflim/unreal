Help out and make UnrealIRCd a better product!

You can do so by reporting issues, testing, programming, documenting,
translating, helping others, and more.
See https://www.unrealircd.org/docs/Contributing
